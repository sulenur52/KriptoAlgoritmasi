﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KriptoAlgoritmasi
{
    class SezarKripto : Kripto
    {


        public override string Desifrele(string desifrelenecekMetin, string anahtar)
        {
            string metin = String.Empty;
            try
            {
                int yeniAnahtar = Convert.ToInt32(anahtar);
                for (int i = 0; i < desifrelenecekMetin.Length; i++)
                {
                    if (KucukAlfabe.Contains(desifrelenecekMetin[i].ToString()))
                    {
                        int indeks = KucukAlfabe.IndexOf(desifrelenecekMetin[i].ToString());
                        int yeniIndeks = ((indeks - (yeniAnahtar % alfabeUzunlugu) + alfabeUzunlugu) % alfabeUzunlugu);
                        metin += KucukAlfabe[yeniIndeks];
                    }
                    else if (BuyukAlfabe.Contains(desifrelenecekMetin[i].ToString()))
                    {
                        int indeks = BuyukAlfabe.IndexOf(desifrelenecekMetin[i].ToString());
                        int yeniIndeks = ((indeks - (yeniAnahtar % alfabeUzunlugu) + alfabeUzunlugu) % alfabeUzunlugu);
                        metin += BuyukAlfabe[yeniIndeks];
                    }
                    else
                    {
                        metin += desifrelenecekMetin[i];
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return metin;
        }

        public override string Sifrele(string sifrelenecekMetin, string anahtar)
        {
            string desifreMetin = String.Empty;
            try
            {
                int yeniAnahtar = Convert.ToInt32(anahtar);
                for (int i = 0; i < sifrelenecekMetin.Length; i++)
                {
                    if (KucukAlfabe.Contains(sifrelenecekMetin[i].ToString()))
                    {
                        int indeks = KucukAlfabe.IndexOf(sifrelenecekMetin[i].ToString());
                        int yeniIndeks = ((indeks + yeniAnahtar) % alfabeUzunlugu);
                        desifreMetin += KucukAlfabe[yeniIndeks];
                    }
                    else if (BuyukAlfabe.Contains(sifrelenecekMetin[i].ToString()))
                    {
                        int indeks = BuyukAlfabe.IndexOf(sifrelenecekMetin[i].ToString());
                        int yeniIndeks = ((indeks + yeniAnahtar) % alfabeUzunlugu);
                        desifreMetin += BuyukAlfabe[yeniIndeks];
                    }
                    else
                    {
                        desifreMetin += sifrelenecekMetin[i];
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            return desifreMetin;
        }

        public override int SifrelenmisMetninAnahtariniBul(string metin, string sifrelenmisMetin)
        {
            int anahtar = 0;
            try
            {
                for (int i = 0; i < metin.Length; i++)
                {
                    if (KucukAlfabe.Contains(metin[i].ToString()))
                    {
                        int metinIndeks = KucukAlfabe.IndexOf(metin[i].ToString());
                        int sifrelenmisMetinIndeks = KucukAlfabe.IndexOf(sifrelenmisMetin[i].ToString());
                        anahtar = Math.Abs(metinIndeks - sifrelenmisMetinIndeks) % alfabeUzunlugu;
                        break;
                    }
                    else if (BuyukAlfabe.Contains(metin[i].ToString()))
                    {
                        int metinIndeks = BuyukAlfabe.IndexOf(metin[i].ToString());
                        int sifrelenmisMetinIndeks = BuyukAlfabe.IndexOf(sifrelenmisMetin[i].ToString());
                        anahtar = Math.Abs(metinIndeks - sifrelenmisMetinIndeks) % alfabeUzunlugu;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return anahtar;
        }

    }
}
