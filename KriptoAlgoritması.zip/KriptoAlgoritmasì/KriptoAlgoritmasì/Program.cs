﻿using System;

namespace KriptoAlgoritmasi
{
    class Program
    {
        static void Main(string[] args)
        {

            Kripto sk = new SezarKripto();
            Kripto vk = new VigenereKripto();

            Console.WriteLine(sk.Sifrele("Turkce..Turkce,,Turkce" , "12"));
            Console.WriteLine(sk.Desifrele("YOSYON..ÖJFts,,FoyQİ", "12"));

            Console.WriteLine(sk.SifrelenmisMetninAnahtariniBul("Turkce..Turkce,,Turkce", "		Türkçe ..Mesaj,,qwerty"));

            Console.WriteLine(vk.Sifrele("XLGSDX", "KEY"));
            Console.WriteLine(vk.Desifrele("XLGSDX", "KEY"));
            Console.ReadLine();
        }
    }
}
