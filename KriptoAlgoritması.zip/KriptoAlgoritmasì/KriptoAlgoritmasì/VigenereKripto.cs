﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KriptoAlgoritmasi
{
    class VigenereKripto : Kripto
    {
        public override string Desifrele(string desifrelenecekMetin, string anahtar)
        {
			return this.Sifrele(desifrelenecekMetin, anahtar, false);
        }

        public override string Sifrele(string sifrelenecekMetin, string anahtar)
        {
			return this.Sifrele(sifrelenecekMetin, anahtar, true);
        }

        public override int SifrelenmisMetninAnahtariniBul(string metin, string sifrelenmisMetin)
        {
            throw new Exception("Bu sifreleme yontemini icin gecerli değildir");
        }

		private static int Mod(int a, int b)
		{
			return (a % b + b) % b;
		}

		private  string Sifrele(string metin, string anahtar, bool sifrelemeTuru)
		{
			for (int i = 0; i < anahtar.Length; ++i)
				if (!char.IsLetter(anahtar[i]))
					return null; // Hata Döndürür (null =boş string)

			string sonuc = string.Empty;
			int harfOlmayanKarakterSayisi = 0;

			for (int i = 0; i < metin.Length; ++i)
			{
				if (char.IsLetter(metin[i]))
				{
					bool cIsUpper = char.IsUpper(metin[i]);
					char ofset = cIsUpper ? 'A' : 'a';
					int anahtarIndeks = (i - harfOlmayanKarakterSayisi) % anahtar.Length;
					int k = (cIsUpper ? char.ToUpper(anahtar[anahtarIndeks]) : char.ToLower(anahtar[anahtarIndeks])) - ofset;
					k = sifrelemeTuru ? k : -k;
					char ch = (char)((Mod(((metin[i] + k) - ofset), 26)) + ofset);
					sonuc += ch;
				}
				else
				{
					sonuc += metin[i];
					++harfOlmayanKarakterSayisi;
				}
			}

			return sonuc;
		}
	}
}
